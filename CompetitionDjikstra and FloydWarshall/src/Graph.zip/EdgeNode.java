
public class EdgeNode {
	int y;
	double weight;
	EdgeNode next;
	public EdgeNode(int y, double weight)
	{
		this.y = y;
		this.weight = weight;
	}
}
